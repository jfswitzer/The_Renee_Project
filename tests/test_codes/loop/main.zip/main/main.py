import time

for i in range(1800):
    print(i)
    time.sleep(1)
