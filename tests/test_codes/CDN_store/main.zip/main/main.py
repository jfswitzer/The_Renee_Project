import cli
directory = cli.get_bucket()
with open(directory+'test.txt','w+') as storage:
    with open("input.txt",'r+') as file:
        for line in file:
            storage.write(line)
