import time
def mapper(key):
    time.sleep(10)
    print("{\"test\": \"1\"\}")
